/**
 * Created by vahriin on 3/3/17.
 */
public class Constants {
    public static final int DIM = 3;
}
